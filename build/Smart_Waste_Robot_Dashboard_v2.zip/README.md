# EcoRoute Smart Waste Robot Dashboard v2

Responsive Review 2 demo dashboard for the project **Web-Based Smart Waste Collection Robot with Robotic Arm and Real-Time Bin Monitoring System**.

## Start on Windows
1. Extract this ZIP file.
2. Open the extracted folder in File Explorer.
3. Click the folder path/address bar, type `cmd`, and press Enter.
4. Run `npm install` (first time only).
5. Run `npm start` and keep that terminal open.
6. Open `http://localhost:3000` on the laptop.

## Open from mobile on the same hotspot/Wi-Fi
Use the `Local network` address printed in the terminal, for example `http://10.x.x.x:3000`. The phone and laptop must be on the same network and Windows Firewall must allow Node.js.

## Mobile camera note
Phone browsers normally require a secure context (HTTPS) for camera access. A plain HTTP laptop IP can load the dashboard but may block the camera API. To enable the phone camera, configure a trusted HTTPS certificate using `certs/cert.pem` and `certs/key.pem`; see the previous project README for mkcert setup guidance. Both devices must be able to reach the server. Some phone hotspots isolate clients.

## Important prototype note
The bin readings, motor buttons, and arm buttons are demo-only until ESP32/sensors/motor driver/servos are integrated. This project is manually controlled, not autonomous. The phone camera feature uses WebRTC and browser permissions; it is separate from a future ESP32-CAM integration.
