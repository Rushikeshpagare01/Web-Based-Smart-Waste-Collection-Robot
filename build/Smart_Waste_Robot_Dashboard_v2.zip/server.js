const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");
const os = require("os");
const express = require("express");
const { Server } = require("socket.io");

const app = express();
const publicDir = path.join(__dirname, "public");
app.use(express.static(publicDir));

const certPath = path.join(__dirname, "certs", "cert.pem");
const keyPath = path.join(__dirname, "certs", "key.pem");
let server;
let protocol = "http";

if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
  server = https.createServer({
    cert: fs.readFileSync(certPath),
    key: fs.readFileSync(keyPath)
  }, app);
  protocol = "https";
} else {
  server = http.createServer(app);
}

const io = new Server(server);
let cameraSocketId = null;

io.on("connection", (socket) => {
  socket.emit("server-info", { protocol });

  socket.on("register-role", ({ role } = {}) => {
    if (role === "camera") {
      cameraSocketId = socket.id;
      socket.data.role = "camera";
      socket.broadcast.emit("camera-status", { online: true });
      socket.emit("camera-role-ready", { ok: true });
      console.log("Mobile camera publisher connected:", socket.id);
    } else {
      socket.data.role = "viewer";
      socket.emit("camera-status", { online: Boolean(cameraSocketId) });
    }
  });

  socket.on("watch-camera", () => {
    if (cameraSocketId && cameraSocketId !== socket.id) {
      io.to(cameraSocketId).emit("viewer-wants-camera", { viewerId: socket.id });
    } else {
      socket.emit("camera-status", { online: false });
    }
  });

  // Relay WebRTC negotiation messages only; video travels peer-to-peer over WebRTC.
  for (const eventName of ["webrtc-offer", "webrtc-answer", "webrtc-ice"]) {
    socket.on(eventName, (payload = {}) => {
      if (typeof payload.to !== "string" || !payload.to) return;
      const allowed = socket.data.role === "camera" || socket.data.role === "viewer";
      if (!allowed) return;
      io.to(payload.to).emit(eventName, { ...payload, from: socket.id });
    });
  }

  socket.on("disconnect", () => {
    if (cameraSocketId === socket.id) {
      cameraSocketId = null;
      socket.broadcast.emit("camera-status", { online: false });
      console.log("Mobile camera publisher disconnected");
    }
    socket.broadcast.emit("peer-disconnected", { peerId: socket.id });
  });
});

function localIPv4s() {
  const found = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const item of list || []) {
      if (item.family === "IPv4" && !item.internal) found.push(item.address);
    }
  }
  return [...new Set(found)];
}

const PORT = Number(process.env.PORT || 3000);
server.listen(PORT, "0.0.0.0", () => {
  console.log(`\nSmart Waste Robot Review 2 demo is running:`);
  console.log(`  This computer: ${protocol}://localhost:${PORT}`);
  for (const ip of localIPv4s()) console.log(`  Local network: ${protocol}://${ip}:${PORT}`);
  if (protocol === "http") {
    console.log("\nNOTE: Mobile camera access usually requires HTTPS on phones.");
    console.log("Add trusted certs at certs/cert.pem and certs/key.pem; see README.");
  }
  console.log("\nKeep this terminal open while demonstrating.\n");
});